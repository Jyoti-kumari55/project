package com.example.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Student;
import com.example.repositories.StudentRepository;



@Service
public class StudentService
{
	@Autowired
	private StudentRepository studentRepository;
	
	public List<Student> findAll() {
		return studentRepository.findAll();
	}
	
	public Student findById(int id) {
		return studentRepository.findById((long) id).get();
	}
	
	@Transactional
	public Student save(Student student) {
		return studentRepository.save(student);
	}
}
	
	/**StudentRepository studentRepository;
	List<Student> findAll();
	void resetCredentials(String username);
	Student findById(Long id);
	Student findByUserId(Long user_id);
	void delete(Long id);
	Student update(Long id);
	boolean isUSernameUnique(String username);**/
	
	


