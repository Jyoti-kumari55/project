package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.example.repositories.AdminRepository;

@Service
public class AdminService {
	

	@Autowired
	AdminRepository adminRepository;
	
	public Admin save(Admin admin)
	{
		return adminRepository.save(admin);
	}
	public List<Admin>getAll(){
		return(List<Admin>) adminRepository.findAll();
	}
	
		public Admin getAdminbyusername(String username) {
		return adminRepository.findByUsername(username);
	}
	
}
