package com.example.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Parent;

import com.example.repositories.ParentRepository;

@Service
public class ParentService {

	@Autowired
	ParentRepository pRepo;
	
	public List<Parent> findAllDetail() {
		return pRepo.findAll();
	}
	
	public Parent findById(int id) {
		return pRepo.findById((long) id).get();
	}
	
	@Transactional
	public Parent save(Parent parent) {
		return pRepo.save(parent);
	}
}

