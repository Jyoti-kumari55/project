package com.example.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Assignment;
import com.example.repositories.AssignmentRepository;

@Service
public class AssignmentService {

	@Autowired 
	AssignmentRepository assignmentRepository;
	
	public Assignment addStudentAss(Assignment assignment) {
		return assignmentRepository.saveAndFlush(assignment);
	}




}
