package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Student;
import com.example.repositories.StudentRepository;
import com.example.repositories.TeacherRepository;



@Service
public class TeacherService {
	@Autowired
	private TeacherRepository teacherRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	
	public List<Student> getAllStudents(){
		
		System.out.println("---------Get All Students--------");
		return studentRepository.findAll();
	
	}
	
	

}
