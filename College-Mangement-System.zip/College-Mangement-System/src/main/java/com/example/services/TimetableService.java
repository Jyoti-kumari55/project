package com.example.services;


import java.util.List;

import com.example.entity.Timetable;

public interface TimetableService {

	
	void addTimetable(Timetable timetable);
	
	List<Timetable> getTimetable();
}
