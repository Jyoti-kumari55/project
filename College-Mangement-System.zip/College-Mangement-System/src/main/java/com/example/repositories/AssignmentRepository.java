package com.example.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Assignment;


public interface AssignmentRepository extends JpaRepository<Assignment, Integer>{

}
