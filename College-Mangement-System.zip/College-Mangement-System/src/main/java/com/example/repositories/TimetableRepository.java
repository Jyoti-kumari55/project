package com.example.repositories;

import org.springframework.data.repository.CrudRepository;
import com.example.entity.Timetable;



public interface TimetableRepository extends CrudRepository<Timetable, Integer>{

}
