package com.example.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Course;
import com.example.entity.Parent;
import com.example.entity.Student;
import com.example.services.ParentService;
import com.example.services.StudentService;

@RestController
@RequestMapping("/parents")
public class ParentController {

	@Autowired
	private ParentService pservice;
	
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/addP")
	public Parent add(@RequestBody Parent parent) {
		return pservice.save(parent);
	}
	
	
}
