package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Admin;
import com.example.services.AdminService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(value = "/admin")
public class AdminController {
	
	@Autowired
	AdminService adminservice;
	
	@GetMapping(value = "/admin/admin/add")
	public String addUser(@ModelAttribute("newAdmin")Admin admin, Model model) {
		return "addAdmin";
		
	}
	
	@PostMapping("/saveAdmin")
	public boolean saveAdmin(@RequestParam("username") String username,@RequestParam("password") String password)
	{
		Admin admin= adminservice.getAdminbyusername(username);
		if(username==admin.getUsername() && password==admin.getPassword())
			      return true;
		else
			return false;
	}
	
	
	

}
