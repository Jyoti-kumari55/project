package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.example.entity.Assignment;
import com.example.services.AssignmentService;
@Controller
public class AssignmentController {

    @Autowired
    AssignmentService assignmentService;	
	
    //add Student Assignment
	public Assignment addStudent(Assignment assignment) {
		return assignmentService.addStudentAss(assignment);
	}
}
